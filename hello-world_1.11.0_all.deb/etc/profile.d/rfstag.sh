#!/bin/sh

export KIOSK_BRIGADE=$(hostname)
export BUSHFIRE_SERVER=rfstag.com
