#!/bin/bash

#tst

export KIOSK_BRIGADE=$(hostname)
export BUSHFIRE_SERVER=rfstag.com
export NFC_INI_FILE=/home/pi/.config/nfcreader.ini
