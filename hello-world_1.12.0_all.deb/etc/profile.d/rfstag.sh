#!/bin/bash

export KIOSK_BRIGADE=$(hostname)
export BUSHFIRE_SERVER=rfstag.com
